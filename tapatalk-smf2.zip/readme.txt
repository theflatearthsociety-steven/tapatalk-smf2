[center][color=red][size=18pt]Tapatalk for SMF Plugin[/size][/color][/center]
[center][size=8pt]For SMF 2.0 RC5/Final, http://www.tapatalk.com[/size][/center]

[b]What is Tapatalk?[/b]
Tapatalk is a forum app for iPhone/iPad, Android, BlackBerry, Windows Phone and WebOS. The app provides super fast forum access to any vBulletin, IPBoard, phpBB, SMF, xenForo, MyBB and Kunena forums that have activated Tapatalk. Forum owner can download the free plug-in to activate Tapatalk in your forum.

[b]What does this mod do?[/b]
This mod enables your forum to be accessed by the Tapatalk app. The Tapatalk app can be downloaded from Apple iTune Store or from Google Android Market.

[b]What next do I have to do?[/b]
After installing this mod, head straight to http://tapatalk.com/activate_tapatalk.php and register there. After registering you can enlist your forum into the Tapatalk network.

[center][color=red][size=18pt]Please manually change permission of all files under mobiquo/ folder (including the folder itself) to chmod 755 otherwise it won't work!![/size][/color][/center]
[center][color=red][size=12pt]Please check on Forum_Root/mobiquo/config/config.txt to make sure that the config content is displayed well.(Forum_Root is the forum url you filled in forum owner area: http://tapatalk.com/forum_owner.php")[/size][/color][/center]

For more information please visit http://tapatalk.com

Thank you! :)